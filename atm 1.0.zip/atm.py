from tkinter import *
import sqlite3
from tkinter import messagebox
import numpy as np

ARIAL = ("arial",10,"bold")

class Bank:
    def __init__(self,root):
        self.conn = sqlite3.connect("atm_databse.db", timeout=100)
        self.login = False
        self.root = root
        self.header = Label(self.root,text="IIST BANK",bg="#50A8B0",fg="white",font=ARIAL)
        self.header.pack(fill=X)
        self.home()
        
    def home(self):
        self.frame = Frame(self.root,bg="#728B8E",width=1366,height=768)
        self.userlabel =Label(self.frame,text="Choose Authentication Type",bg="#728B8E",fg="white",font=ARIAL)
        self.userlabel.place(x=585,y=200,width=200,height=20)
        self.button1 = Button(self.frame,text="PIN",bg="#50A8B0",fg="white",font=ARIAL,command=self.pin)
        self.button1.place(x=550,y=300,width=120,height=25)
        self.button2 = Button(self.frame,text="OTP",bg="#50A8B0",fg="white",font=ARIAL,command=self.otp)
        self.button2.place(x=700,y=300,width=120,height=25)
        self.q = Button(self.frame,text="Quit",bg="#50A8B0",fg="white",font=ARIAL,command = self.root.destroy)
        self.q.place(x=1230,y=650,width=120,height=20)
        
        self.frame.pack()
        
    def pin(self):
        self.userlabel =Label(self.frame,text="Account Number",bg="#728B8E",fg="white",font=ARIAL)
        self.userlabel.place(x=500,y=200,width=200,height=20)
        #vcmd = (root.register(self.validate),'%d', '%i', '%P', '%s', '%S', '%v', '%V', '%W')
        self.uentry = Entry(self.frame,bg="honeydew",highlightcolor="#50A8B0",highlightthickness=2,highlightbackground="white")
        self.uentry.place(x=700,y=200,width=200,height=20)
        self.plabel = Label(self.frame, text="Password",bg="#728B8E",fg="white",font=ARIAL)
        self.plabel.place(x=550,y=250,width=120,height=20)
        self.pentry = Entry(self.frame,bg="honeydew",show="*",highlightcolor="#50A8B0",highlightthickness=2,highlightbackground="white")
        self.pentry.place(x=700,y=250,width=200,height=20)
        self.button = Button(self.frame,text="LOGIN",bg="#50A8B0",fg="white",font=ARIAL,command=self.verification)
        self.button.place(x=550,y=300,width=300,height=25)
        
    def otp(self):
        self.userlabel =Label(self.frame,text="Account Number",bg="#728B8E",fg="white",font=ARIAL)
        self.userlabel.place(x=500,y=200,width=200,height=20)
        self.uentry = Entry(self.frame,bg="honeydew",highlightcolor="#50A8B0",highlightthickness=2,highlightbackground="white")
        self.uentry.place(x=700,y=200,width=200,height=20)
        self.otpin = Label(self.frame, text="OTP",bg="#728B8E",fg="white",font=ARIAL)
        self.otpin.place(x=550,y=250,width=120,height=20)
        self.eotp = Entry(self.frame,bg="honeydew",show="*",highlightcolor="#50A8B0",highlightthickness=2,highlightbackground="white")
        self.eotp.place(x=700,y=250,width=200,height=20)
        self.genotp = Button(self.frame,text="Get OTP",bg="#50A8B0",fg="white",font=ARIAL,command=self.generator)
        self.genotp.place(x=910,y=250,width=120,height=20)
        self.log = Button(self.frame,text="LOGIN",bg="#50A8B0",fg="white",font=ARIAL,command=self.verify)
        self.log.place(x=550,y=300,width=300,height=25)
        
    def generator(self):
        global a1
        a1=np.random.randint(1000,9999)
        messagebox._show("OTP", a1)
    
    def validate(self, action, index, value_if_allowed,prior_value, text, validation_type, trigger_type, widget_name):
        if text in '0123456789.-+':
            try:
                float(value_if_allowed)
                return True
            except ValueError:
                return False
        else:
            return False
        
    def verify(self):
        ac = False
        self.temp = self.conn.execute("select name,pass,acc_no,acc_type,bal from atm where acc_no = ? ", (int(self.uentry.get()),))
        
        for i in self.temp:
            self.ac = i[2]
            if i[2] == self.uentry.get():
                ac = True
            elif a1 == int(self.eotp.get()):
                ac = True
                m = "{} Login SucessFull".format(i[0])
                self.database_fetch()
                messagebox._show("Login Info", m)
                self.frame.destroy()
                self.MainMenu()
            else:
                ac = True
                m = " Login UnSucessFull ! Wrong Password"
                messagebox._show("Login Info!", m)

        if not ac:
            m = " Wrong Account Number !"
            messagebox._show("Login Info!", m)
            
    def verification(self):
        ac = False
        self.temp = self.conn.execute("select name,pass,acc_no,acc_type,bal from atm where acc_no = ? ", (int(self.uentry.get()),))
        
        for i in self.temp:
            self.ac = i[2]
            if i[2] == self.uentry.get():
                ac = True
            elif i[1] == self.pentry.get():
                ac = True
                m = "{} Login SucessFull".format(i[0])
                self.database_fetch()
                messagebox._show("Login Info", m)
                self.frame.destroy()
                self.MainMenu()
            else:
                ac = True
                m = " Login UnSucessFull ! Wrong Password"
                messagebox._show("Login Info!", m)

        if not ac:
            m = " Wrong Acoount Number !"
            messagebox._show("Login Info!", m)
            
    def database_fetch(self):
        self.acc_list = []
        self.temp = self.conn.execute("select name,pass,acc_no,acc_type,bal from atm where acc_no = ? ",(self.ac,))
        for i in self.temp:
            self.acc_list.append("Name = {}".format(i[0]))
            self.acc_list.append("Account no = {}".format(i[2]))
            self.acc_list.append("Account type = {}".format(i[3]))
            self.ac = i[2]
            self.acc_list.append("Balance = {}".format(i[4]))
            
            
    def MainMenu(self):
        self.frame = Frame(self.root,bg="#728B8E",width=1350,height=760)
        root.geometry("1350x760")
        self.detail = Button(self.frame,text="Account Details",bg="#50A8B0",fg="white",font=ARIAL,command=self.account_detail)
        self.detail.place(x=0,y=0,width=200,height=50)
        self.enquiry = Button(self.frame, text="Balance Enquiry",bg="#50A8B0",fg="white",font=ARIAL,command= self.Balance)
        self.enquiry.place(x=0, y=630, width=200, height=50)
        self.deposit = Button(self.frame, text="Deposit Money",bg="#50A8B0",fg="white",font=ARIAL,command=self.deposit_money)
        self.deposit.place(x=1150, y=0, width=200, height=50)
        self.withdrawl = Button(self.frame, text="Withdrawl Money",bg="#50A8B0",fg="white",font=ARIAL,command=self.withdrawl_money)
        self.withdrawl.place(x=1150, y=630, width=200, height=50)
        self.q = Button(self.frame, text="Quit", bg="#50A8B0", fg="white", font=ARIAL, command=self.root.destroy)
        self.q.place(x=630, y=650, width=120, height=20)
        self.frame.pack()
        
    def account_detail(self):
        self.database_fetch()
        text = self.acc_list[0]+"\n"+self.acc_list[1]+"\n"+self.acc_list[2]
        self.label = Label(self.frame,bg="#728B8E",text=text,font=ARIAL)
        self.label.place(x=550,y=270,width=300,height=200)

    def Balance(self):
        self.database_fetch()
        self.label = Label(self.frame,bg="#728B8E",text=self.acc_list[3],font=ARIAL)
        self.label.place(x=550, y=270, width=300, height=200)

    def deposit_money(self):
        self.money_box = Entry(self.frame,bg="honeydew",highlightcolor="#50A8B0",highlightthickness=2,highlightbackground="white")
        self.money_box.place(x=550,y=300,width=200,height=30)
        self.submitButton = Button(self.frame,text="Submit",bg="#50A8B0",fg="white",font=ARIAL,command=self.deposit_trans)
        self.submitButton.place(x=700,y=300,width=55,height=30)

    def deposit_trans(self):
        self.conn.execute("update atm set bal = bal + ? where acc_no = ?",(self.money_box.get(),self.ac))
        self.label = Label(self.frame,bg="#728B8E", text="Transaction Completed !", font=ARIAL)
        self.label.place(x=550, y=300, width=230, height=100)
        self.conn.commit()

    def withdrawl_money(self):
        
        #vcmd = (root.register(self.validate),'%d', '%i', '%P', '%s', '%S', '%v', '%V', '%W')
        mon=self.money_box = Entry(self.frame,bg="honeydew",highlightcolor="#50A8B0",highlightthickness=2,highlightbackground="white")
        self.money_box.place(x=550,y=300,width=200,height=30)
        self.submitButton = Button(self.frame,text="Submit",bg="#50A8B0",fg="white",font=ARIAL,command=self.withdrawl_trans)
        self.submitButton.place(x=700,y=300,width=55,height=30)

    def withdrawl_trans(self):
        self.label = Label(self.frame, text="Money Withdrawl !",bg="#728B8E", font=ARIAL)
        self.label.place(x=550, y=300, width=230, height=100)
        x=int(mon.get())
        self.temp = self.conn.execute("select bal from atm where acc_no = ? ",(self.ac,))
        self.abc=self.temp.fetchone()
        print(self.abc)
        z=int(self.abc[0])
        if (x>z):
            self.userlabel =Label(self.frame,text="Insufficent Balance",bg="#728B8E",fg="white",font=ARIAL)
            self.userlabel.place(x=550,y=300,width=230,height=100)
            self.conn.commit()
        else:
            self.conn.execute("update atm set bal = bal - ? where acc_no = ?",(self.money_box.get(),self.ac))
        self.conn.commit()
        
        
root = Tk()
root.title("ATM")
root.geometry("1350x760")
obj = Bank(root)
root.mainloop()